from app.models.resume import ResumeData
from app.models.result import EligibilityResult


PYTHON_SIGNALS = {
    "python",
    "fastapi",
    "django",
    "flask",
    "pytest",
    "pydantic",
    "pandas",
    "numpy",
    "sqlalchemy",
    "asyncio",
}

AI_SIGNALS = {
    "langchain",
    "langgraph",
    "google adk",
    "llamaindex",
    "llama index",
    "rag",
    "retrieval augmented generation",
    "embeddings",
    "vector search",
    "vector database",
    "vector db",
    "tool calling",
    "tool-calling",
    "multi-agent",
    "multi agent",
    "agentic",
    "ai agent",
    "llm",
    "large language model",
    "evaluation pipeline",
}


def _normalise(value: str) -> str:
    return " ".join(value.lower().split())


def _find_signals(text: str, signals: set[str]) -> list[str]:
    normalised = _normalise(text)

    return [
        signal
        for signal in signals
        if signal in normalised
    ]


def _build_search_text(resume: ResumeData) -> str:
    parts = [
        " ".join(resume.skills),
        " ".join(resume.education),
    ]

    for experience in resume.experience:
        parts.extend(
            [
                experience.role,
                experience.description,
                " ".join(experience.technologies),
            ]
        )

    for project in resume.projects:
        parts.extend(
            [
                project.name,
                project.description,
                " ".join(project.technologies),
                " ".join(project.evidence),
            ]
        )

    return "\n".join(parts)


def check_eligibility(resume: ResumeData) -> EligibilityResult:
    search_text = _build_search_text(resume)

    python_evidence = _find_signals(
        search_text,
        PYTHON_SIGNALS,
    )

    ai_evidence = _find_signals(
        search_text,
        AI_SIGNALS,
    )

    rejection_reasons: list[str] = []

    if not python_evidence:
        rejection_reasons.append(
            "No evidence of Python stack"
        )

    if not ai_evidence:
        rejection_reasons.append(
            "No AI/agentic project or implementation evidence"
        )

    return EligibilityResult(
        eligible=not rejection_reasons,
        python_evidence=python_evidence,
        ai_evidence=ai_evidence,
        rejection_reasons=rejection_reasons,
    )