import os
from dataclasses import dataclass
from urllib.parse import urlparse

import httpx

from app.models.result import GitHubResult


GITHUB_API_BASE = "https://api.github.com"


@dataclass
class GitHubProfile:
    username: str
    repositories: list[dict]
    events: list[dict]


class GitHubEnricher:
    def __init__(self) -> None:
        self.token = os.getenv("GITHUB_TOKEN")
        self._cache: dict[str, GitHubResult] = {}

    def enrich(self, github_url: str | None) -> GitHubResult:
        if not github_url:
            return GitHubResult(
                status="not_available",
                score=0,
                summary="No GitHub profile found in resume.",
            )

        username = self._extract_username(github_url)

        if not username:
            return GitHubResult(
                status="invalid_url",
                score=0,
                summary="GitHub URL could not be parsed.",
            )

        if username in self._cache:
            return self._cache[username]

        try:
            profile = self._fetch_profile(username)
            result = self._calculate_score(profile)

        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 404:
                result = GitHubResult(
                    status="not_found",
                    score=0,
                    summary="GitHub profile was not found.",
                )
            elif exc.response.status_code == 403:
                result = GitHubResult(
                    status="rate_limited",
                    score=0,
                    summary="GitHub API rate limit reached.",
                )
            else:
                result = GitHubResult(
                    status="api_error",
                    score=0,
                    summary=(
                        f"GitHub API returned HTTP "
                        f"{exc.response.status_code}."
                    ),
                )

        except (httpx.HTTPError, ValueError) as exc:
            result = GitHubResult(
                status="failed",
                score=0,
                summary=f"GitHub enrichment failed: {exc}",
            )

        self._cache[username] = result
        return result

    def _headers(self) -> dict[str, str]:
        headers = {
            "Accept": "application/vnd.github+json",
        }

        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"

        return headers

    def _fetch_profile(self, username: str) -> GitHubProfile:
        timeout = httpx.Timeout(10.0)

        with httpx.Client(
            base_url=GITHUB_API_BASE,
            headers=self._headers(),
            timeout=timeout,
        ) as client:

            user_response = client.get(f"/users/{username}")
            user_response.raise_for_status()

            repos_response = client.get(
                f"/users/{username}/repos",
                params={
                    "sort": "updated",
                    "per_page": 20,
                    "type": "owner",
                },
            )
            repos_response.raise_for_status()

            events_response = client.get(
                f"/users/{username}/events/public",
                params={"per_page": 30},
            )
            events_response.raise_for_status()

            return GitHubProfile(
                username=username,
                repositories=repos_response.json(),
                events=events_response.json(),
            )

    def _calculate_score(
        self,
        profile: GitHubProfile,
    ) -> GitHubResult:
        repositories = profile.repositories
        events = profile.events

        recent_activity_score = min(len(events), 5)

        relevant_repositories = 0

        for repo in repositories:
            language = (repo.get("language") or "").lower()
            topics = " ".join(repo.get("topics") or []).lower()
            name = (repo.get("name") or "").lower()
            description = (repo.get("description") or "").lower()

            searchable = (
                f"{language} {topics} {name} {description}"
            )

            if any(
                signal in searchable
                for signal in (
                    "python",
                    "fastapi",
                    "django",
                    "flask",
                    "ai",
                    "llm",
                    "langchain",
                    "langgraph",
                    "rag",
                    "machine learning",
                )
            ):
                relevant_repositories += 1

        repository_score = min(relevant_repositories, 5)

        score = recent_activity_score + repository_score
        score = min(score, 10)

        if score == 0:
            summary = "No meaningful recent public activity detected."
        else:
            summary = (
                f"Found {len(events)} recent public events and "
                f"{relevant_repositories} relevant maintained repositories."
            )

        return GitHubResult(
            status="success",
            score=score,
            summary=summary,
        )

    @staticmethod
    def _extract_username(url: str) -> str | None:
        try:
            parsed = urlparse(url.strip())

            if parsed.netloc.lower() not in {
                "github.com",
                "www.github.com",
            }:
                return None

            path_parts = [
                part for part in parsed.path.strip("/").split("/")
                if part
            ]

            if not path_parts:
                return None

            username = path_parts[0]

            # Ignore repository URLs such as /user/repository.
            return username

        except Exception:
            return None